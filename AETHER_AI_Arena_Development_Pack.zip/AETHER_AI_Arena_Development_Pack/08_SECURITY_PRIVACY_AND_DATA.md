# 08 — SECURITY, PRIVACY AND DATA HANDLING
## Secrets
Never store API keys, OAuth client secrets, GitHub App private keys, access/refresh tokens, cookies or relay credentials in:
- Flutter source/assets;
- Git repository or Git history;
- conversation snapshots;
- logs, analytics or crash reports;
- unencrypted backups.

Use server-side secret storage or GitHub Actions encrypted secrets only where appropriate. Android secure storage may hold short-lived user tokens, protected by platform facilities, but long-lived provider credentials should not be embedded in the APK.

## OAuth
- Use authorization code + PKCE where supported.
- Validate `state`, redirect URI, issuer/host, and callback parameters.
- Prefer system browser, not an embedded WebView.
- Request least privilege and explain every scope.
- Store refresh tokens securely and rotate/revoke.
- Do not treat a connected account as blanket permission for every action.

## Tool approvals
Require explicit confirmation for:
- sending email or messages;
- deleting files/repositories;
- publishing/deploying;
- modifying calendar events;
- changing permissions;
- spending money or starting billable resources;
- running untrusted scripts or commands with elevated privileges.

## Skills and code execution
- Treat third-party skills, prompts, ZIPs and repositories as untrusted.
- Scan files and scripts.
- Show source, author, version, requested capabilities and risk.
- Run commands in isolated least-privilege environment.
- Do not let skill text override platform security rules.
- Log action metadata without sensitive content.

## User privacy
- User can view, export and delete profile/memory/conversations.
- Provide data retention and backup policy.
- Avoid storing unnecessary personal information.
- Use encryption in transit and at rest.
- Keep audit trail for sensitive operations.
