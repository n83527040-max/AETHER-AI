# 02 — AETHER AI PROJECT SPECIFICATIONS (SRS)
## 1. Purpose
AETHER AI is an Android-first Flutter client and control plane for a personal autonomous Hermes Agent. It manages agent identity, provider connections, integrations, skills, projects, conversations, persistent memory, and temporary compute sessions.

## 2. User roles
- Owner: authenticated GitHub user; controls repository, integrations, credentials and agent.
- Agent: Hermes runtime acting only within granted permissions.
- Runtime worker: ephemeral session environment.
- Service adapter: provider or integration connector.

## 3. Functional requirements

### FR-01 Authentication
- Sign in with GitHub using a secure supported OAuth/GitHub App flow.
- Display authenticated account and installation/authorization status.
- Support revoke/disconnect.
- Never expose secrets in UI logs or analytics.

### FR-02 Workspace repository
- List repositories available to the authenticated user/installation.
- Select an existing repository or create a new private repository.
- Validate repository access and required permissions.
- Repository deletion is not part of ordinary setup; if added, require typed repository name and two confirmations.
- Show selected owner/name/default branch/visibility.

### FR-03 User and agent profile
- Collect preferred user name, language, timezone, optional profile notes.
- Collect agent name, avatar, communication style, language and persona instructions.
- Allow editing after setup.

### FR-04 Provider management
- Support OpenRouter, OpenAI API, Anthropic, Gemini, DeepSeek, Groq, Ollama, Hugging Face and custom compatible endpoints where supported.
- Add/test/update/revoke API credentials.
- Discover models dynamically and choose default/fallback.
- Mark model price and free status only from fresh authoritative metadata.

### FR-05 Agent provisioning
- Start a verified runtime workflow.
- Install a pinned Hermes release/commit and dependencies.
- Apply selected model/provider configuration.
- Restore approved memory, conversations, projects and skills.
- Run health checks before marking Running.

### FR-06 Chat
- Stream agent replies.
- Render Markdown and code.
- Support conversation create/search/pin/archive/delete.
- Store durable conversation snapshots.
- Show task status and tool-use summaries without hidden reasoning.

### FR-07 Skills Manager
- Discover skills from supported official/community catalogs.
- Search, filter, inspect, install, update, disable, uninstall.
- Create skill with SKILL.md and optional supporting files.
- Import supported ZIP/repository sources.
- Run security checks and permission review before activation.
- Persist skill manifests and approved files.

### FR-08 Integrations
- Connect Drive, Gmail, Calendar, Sheets, GitHub, Telegram and supported MCP/custom services.
- Display scopes and account identity.
- Test, revoke, reconnect and audit actions.
- Use read-only defaults; request write scopes only when the user enables the relevant feature.

### FR-09 Memory and persistence
- Store user-approved profile and memory.
- Snapshot conversations, skills, project metadata and agent configuration.
- Encrypt sensitive user data before repository storage where appropriate.
- Never store secrets in Git.
- Provide export, restore, rollback and delete controls.

### FR-10 Session management
- Session states: Idle, Queued, Starting, Installing, Restoring, Running, Checkpointing, Stopping, Stopped, Failed, RecoveryRequired.
- Max requested session duration: 5 hours.
- Warn before shutdown.
- Checkpoint and verify remote save before stopping.
- Resume starts a fresh runtime and restores the last verified checkpoint.
- Prevent duplicate active sessions per workspace.

### FR-11 Projects and files
- List projects and checkpoint state.
- Allow user-selected local files via Android system picker.
- Show uploaded/downloaded files and provenance.
- Do not silently scan all device storage.

### FR-12 Settings and audit
- Manage agent identity, language, privacy, notification preferences, security and data export.
- Show recent privileged actions and approvals.

## 4. Non-functional requirements
- Reliability: no false Running state; explicit save confirmation.
- Security: least privilege, secret isolation, token rotation, audit trail.
- Performance: responsive scrolling and streaming; pagination for history and skills.
- Accessibility: readable contrast, scalable fonts, screen-reader labels.
- Localization: Arabic RTL, English LTR, French LTR.
- Maintainability: modular feature-first architecture, tests and documented APIs.
- Observability: redacted logs, correlation IDs, no prompts/secrets in crash reports.

## 5. Out of scope unless separately approved
- Always-on 24/7 server on GitHub Actions.
- Arbitrary control of Google Colab runtime without a supported API.
- Hidden access to all Android files.
- Automatic sending/deleting/publishing without user approval.
- Storing raw credentials in GitHub repository.
- Guaranteeing free model availability or unlimited quotas.

## 6. Main navigation
No bottom navigation bar. Top-left hamburger opens a drawer containing:
New Chat; Search Chats; recent chats; pinned chats; Skills Manager; AI Providers; Integrations; Memory & Data; Projects; GitHub Workspace; Sessions; Settings.

## 7. Data entities
UserProfile, AgentProfile, WorkspaceRepository, ProviderConnectionMetadata, SecretReference, Conversation, Message, SkillManifest, IntegrationConnection, PermissionGrant, Project, Session, Checkpoint, AuditEvent, FileReference.

Provider secrets must be represented by references to a secure secret store, never as plain fields in these entities.
