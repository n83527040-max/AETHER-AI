# 06 — FEATURES AND ACCEPTANCE TESTS
## Acceptance checklist
### Identity and onboarding
- [ ] AETHER icon appears in launcher, splash and app header.
- [ ] GitHub login uses secure system-browser authorization and validates callback state.
- [ ] User sees GitHub account and requested scopes before approval.
- [ ] Existing private repo can be selected.
- [ ] New private repo can be created if verified permissions support it.
- [ ] Profile and agent persona are saved and editable.
- [ ] No sample identity or fake connection is shown as real.

### AI Providers
- [ ] User can add/remove provider credentials.
- [ ] Keys are masked and never logged.
- [ ] Provider connection test returns accurate success/error.
- [ ] Model list is fetched from live provider metadata where supported.
- [ ] Default and fallback model can be configured.
- [ ] Free model labels include source and last-checked time.
- [ ] ChatGPT/Claude consumer subscription is not described as API credit.

### Hermes runtime
- [ ] Hermes version is pinned and install is reproducible.
- [ ] Runtime reports true readiness only after a test prompt succeeds.
- [ ] Chat messages stream to the app.
- [ ] Tool activity is visible as status, not hidden chain-of-thought.
- [ ] User can cancel a running task.
- [ ] Runtime failures are surfaced with actionable errors.

### Skills
- [ ] Catalog can search and filter.
- [ ] Skill detail shows source, version, files, permissions and risk.
- [ ] Skill install validates format and scans content/scripts.
- [ ] User approves dangerous tools before activation.
- [ ] Custom skill can be created and exported.
- [ ] Skills persist and restore after a new session.

### Integrations
- [ ] Each service has independent scopes and disconnect.
- [ ] Read-only default where possible.
- [ ] Sending email, deleting files or publishing asks for approval.
- [ ] Expired tokens are detected and reauthorization is guided.
- [ ] Unsupported Colab control is not represented as implemented.

### Memory and session
- [ ] Conversation survives app restart.
- [ ] Checkpoint is stored remotely and hash verified.
- [ ] Resume creates a new session and restores last verified checkpoint.
- [ ] Failed save never displays Saved.
- [ ] Duplicate sessions are prevented.
- [ ] Runtime stops before 5-hour product deadline.
- [ ] User can export/delete personal data and repository snapshots.

### Flutter quality
- [ ] `flutter analyze` passes.
- [ ] `dart format --set-exit-if-changed .` passes.
- [ ] Unit/widget/integration tests pass.
- [ ] RTL Arabic layout works.
- [ ] No overflow on 360px-wide screen.
- [ ] Keyboard does not cover composer.
- [ ] Deep-link OAuth callback is validated.
- [ ] Release APK/AAB builds reproducibly.

## Required test matrix
- No GitHub account / denied OAuth / cancelled OAuth.
- Wrong callback state / expired token / revoked App.
- Repository list empty / no access / repo deleted / default branch missing.
- Provider key invalid / quota exhausted / model unavailable / timeout.
- Hermes install failure / version mismatch / unsupported model context.
- Skills with suspicious scripts / malformed SKILL.md / dependency unavailable.
- Network disconnect during streaming / relay reconnect.
- Checkpoint conflict / failed push / corrupted hash / repo quota.
- Session deadline / user stop / workflow cancellation / duplicate start.
- Android app killed and relaunched / orientation / Arabic RTL / low memory.
