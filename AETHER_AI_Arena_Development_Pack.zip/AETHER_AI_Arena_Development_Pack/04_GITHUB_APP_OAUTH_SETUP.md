# 04 — GITHUB APP VS OAUTH APP: DECISION AND SETUP FORM
## Do not create either app until research is complete.

### Decision summary
**GitHub App is the preferred candidate** when AETHER needs repository-scoped granular permissions, installation tokens and GitHub App identity. A **GitHub OAuth App** may be simpler for user sign-in but can require broader classic scopes and does not automatically grant every repository or Actions operation. Verify all current endpoints and permission rules before choosing.

### Ask the user to choose
Present two selectable options:
1. **GitHub App (recommended if it satisfies all required operations)** — granular permissions, installation-based repository access, short-lived installation tokens; requires App ID/private key and user authorization where needed.
2. **GitHub OAuth App** — user sign-in and user-authorized scopes; requires Client ID and Client Secret; verify whether it covers workflow and repository operations.

Show a comparison of security, repository selection, creating repositories, dispatching workflows, deleting repositories, permission granularity, setup complexity, and secret handling. Recommend one based on current research. Wait for the user.

## GitHub App setup checklist (only if selected)
Collect as configuration fields; never invent values:
- GitHub App Name
- Homepage URL
- Callback URL / user authorization callback
- Setup URL (optional)
- Webhook URL (only if webhooks are used)
- Webhook secret (secret; only if needed)
- App ID (public identifier)
- Client ID (public identifier, if used)
- Client Secret (secret, if user authorization flow requires it)
- Private key PEM (secret file; never paste into ordinary chat)
- App slug
- Installation ID (obtained after installation)
- Account owner (GitHub username/org)
- Selected repository access: all repos or selected repos
- Repository permissions, with justification:
  - Metadata: read (normally required)
  - Contents: read/write only if reading/writing repository files
  - Actions: read/write only if listing/running workflows is required
  - Workflows: write only if changing workflow files is required
  - Pull requests/issues/checks only if product features require them
  - Administration only if repository creation/deletion or settings management genuinely requires it; avoid broad access.
- Subscribe only to required webhook events.
- Callback URI exact match.
- Local development and production URLs.

## OAuth App setup checklist (only if selected)
- OAuth App Name
- Homepage URL
- Authorization callback URL
- Client ID (public)
- Client Secret (secret)
- Whether Device Flow is enabled (only if used)
- Required scopes, with explanation and least privilege
- Local development and production callback URLs
- Account used to register the app

Do not assume OAuth scopes are equivalent to GitHub App permissions. Verify current scope names and API requirements.

## Credential entry form behavior
The app/developer tool should show:
| Field | Example placeholder only | Public or secret | Where to obtain |
| App ID | `YOUR_APP_ID` | Public | GitHub App settings |
| Client ID | `YOUR_CLIENT_ID` | Public | GitHub App/OAuth settings |
| Client Secret | `••••••••` | Secret | Generate in GitHub settings |
| Private key | `Upload .pem` | Secret file | Generate GitHub App private key |
| Callback URL | `https://your-domain.example/callback` | Public URL | Defined by the implementation |
| Webhook secret | `••••••••` | Secret | Generate randomly if webhook is enabled |
| Installation ID | `YOUR_INSTALLATION_ID` | Identifier | After installing the App |
| App slug | `your-app-slug` | Public | GitHub App URL/settings |

The actual callback URL depends on the chosen app ID, application package, backend/relay URL and environment. Generate it only after architecture decisions. Never put an invented callback URL into GitHub settings.

### Security rules
- Client secrets/private keys/tokens must never be committed to Git.
- Never put a GitHub App private key or OAuth client secret in Flutter assets, Dart constants, APK resources or GitHub repository.
- Prefer backend-held secrets or GitHub Actions environment secrets with minimal scope.
- Use short-lived installation tokens; refresh them server-side.
- Redact tokens in logs and crash reports.
- Provide rotation and revoke instructions.
- Ask before enabling repository deletion; never request deletion permission by default.
