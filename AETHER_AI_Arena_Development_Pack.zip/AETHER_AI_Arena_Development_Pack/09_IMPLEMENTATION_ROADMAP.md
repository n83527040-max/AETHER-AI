# 09 — IMPLEMENTATION ROADMAP
## Phase 0 — Research and feasibility (mandatory gate)
Deliver official-source research, version matrix, GitHub Actions feasibility verdict, Hermes integration plan, provider compatibility table and risk register. No production code yet.

## Phase 1 — Architecture and GitHub setup (mandatory user decision)
Present GitHub App vs OAuth App comparison. User chooses. Generate exact configuration fields, callback URLs and permissions based on selected architecture. Wait for required configuration through secure channel.

## Phase 2 — Flutter foundation and design system
Create Flutter project, localization, navigation drawer, theme, icon/splash, reusable components, responsive layouts and tests. Build UI with realistic loading/error/empty states.

## Phase 3 — Authentication and repository workspace
Implement GitHub auth, permissions review, repo list/select/create, workspace validation and secure token handling. Verify using a test account/repo.

## Phase 4 — Provider manager
Implement provider adapters, secret references, model discovery, connection tests, default/fallback and usage metadata.

## Phase 5 — Hermes runtime proof of concept
Install pinned Hermes in the selected supported environment. Prove a real chat round-trip, tool status, provider configuration and secure relay. Do not build all screens around a fake runtime.

## Phase 6 — Persistence and resume
Implement snapshot schema, commit batching, integrity checks, checkpoint, restore, rollback, conflict handling and session locks. Prove stop/restart/resume end-to-end.

## Phase 7 — Skills and integrations
Implement Skills Manager using Hermes-supported skill operations. Add Drive/Gmail/Calendar/Sheets/GitHub/Telegram adapters individually, each with scopes and tests. Add Colab only within documented capabilities.

## Phase 8 — Projects, files, task timeline and settings
Implement project/file management, approvals, audit trail, memory UI, notifications and settings.

## Phase 9 — QA and release
Run unit/widget/integration/security tests, Flutter analyze/format, device matrix, RTL checks, performance review, release build and checksums. Deliver changelog, setup manual and known limitations.

## Gate policy
At each phase, provide a concise completion report with implemented items, tests, blockers, risks and next steps. Never mark a feature complete if it is a mock or has not been tested against a real service.
