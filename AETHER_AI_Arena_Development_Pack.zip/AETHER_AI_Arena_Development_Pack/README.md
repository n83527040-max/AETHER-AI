# AETHER AI — Arena AI Agent Development Pack

This package is the product brief, implementation prompt, visual reference kit, and setup hand-off for building **AETHER AI** as a professional Android application in Flutter.

## Start here
1. Read `01_ARENA_MASTER_PROMPT.md` and give it to Arena AI Agent as the main instruction.
2. Keep `assets/AETHER_AI_App_Icon_1024.png` as the brand icon reference.
3. Give Arena the complete `assets/ui_pages/` folder and the three full concept boards.
4. Arena must complete the research and architecture phase before writing production code.
5. Arena must then present the GitHub integration decision screen and credential checklist. Do not invent credentials.
6. Only after the user chooses GitHub App or OAuth App and provides configuration through a secure local setup flow may implementation proceed.

## Package contents
- `01_ARENA_MASTER_PROMPT.md` — full agent prompt and hard execution gates.
- `02_PROJECT_SPECIFICATIONS.md` — product/SRS requirements.
- `03_RESEARCH_AND_OFFICIAL_SOURCES.md` — required research plan and official source links.
- `04_GITHUB_APP_OAUTH_SETUP.md` — decision guide and exact information checklist.
- `05_ARCHITECTURE_AND_WORKFLOWS.md` — proposed architecture and GitHub Actions lifecycle.
- `06_FEATURES_AND_ACCEPTANCE_TESTS.md` — feature matrix and release acceptance criteria.
- `07_UI_DESIGN_REFERENCE.md` — visual language and page-by-page design notes.
- `08_SECURITY_PRIVACY_AND_DATA.md` — secrets, permissions, data retention, and threat model.
- `09_IMPLEMENTATION_ROADMAP.md` — staged build and testing plan.
- `assets/` — icon and concept boards.
- `assets/ui_pages/` — separate reference image per screen. Some later screens are specification-only placeholder cards; implement them from the written requirements, not as literal UI screenshots.

## Important reality checks
- GitHub Actions is an ephemeral CI runner, not a guaranteed always-on application server. The agent must research GitHub terms, runner limits, network reachability, and supported use before committing to this design.
- The requested session is **5 hours maximum**, with an orderly checkpoint and shutdown before the deadline. Do not use the full runner timeout as the save mechanism.
- Git repositories are not databases or secret vaults. Use private repository storage for versioned, encrypted snapshots and project assets; never commit API keys, OAuth secrets, private keys, access tokens, or raw credentials.
- The Android app must never contain a GitHub App private key, OAuth client secret, provider API key, or long-lived installation token.
- If GitHub-hosted Actions cannot safely or policy-compliantly support interactive agent sessions, explain the limitation and present a compliant alternative (for example, a user-managed self-hosted runner or a dedicated compute service) for approval. Do not silently change the requested hosting model.
