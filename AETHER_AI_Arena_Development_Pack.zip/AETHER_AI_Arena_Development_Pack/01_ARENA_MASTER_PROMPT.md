# 01 — MASTER PROMPT FOR ARENA AI AGENT
## Project: AETHER AI
### Your Personal Autonomous AI Agent

You are the principal product researcher, Flutter architect, UX designer, security engineer, and implementation agent responsible for delivering **AETHER AI**, a production-quality Android application built with Flutter.

The user wants a real, buildable, tested application—not a static prototype, a WebView wrapper, or a set of disconnected mock screens.

---

## A. Mission and non-negotiable workflow

Build an Android-first Flutter application that provides a polished mobile workspace for a personal autonomous AI agent powered by **Hermes Agent**. The requested compute environment is **GitHub Actions**, with a maximum working session of **5 hours**, followed by checkpoint, durable save, and shutdown. The user must be able to reopen the app and choose **Resume Agent**, which provisions a fresh session and restores the agent's state.

### Mandatory phase gates
**Do not start production implementation immediately.**

1. **Research first.** Study current official Flutter documentation, current Hermes Agent documentation/source, GitHub Apps and OAuth Apps, GitHub Actions runner limits and security, provider API documentation, Android permissions/storage, and all integrations. Use current primary sources. Record the date accessed and relevant version/commit.
2. **Reality and feasibility report.** Explain what can and cannot be done with GitHub-hosted Actions, especially interactive long-running processes, outbound connectivity, WebSocket relay, persistence, and GitHub acceptable-use/policy. Do not assume an Actions runner is a VPS or inbound-reachable server.
3. **Architecture proposal.** Deliver architecture diagrams, trust boundaries, data flow, authentication flow, storage model, lifecycle workflow, and failure/recovery design.
4. **GitHub authentication decision gate.** Present a clear choice between **GitHub App** and **GitHub OAuth App**. Recommend one with evidence and explain trade-offs. Do not request secrets yet.
5. **Credential/setup form gate.** After the user chooses, present the exact fields and setup instructions required for that option. Use a secure local secret-entry flow; never ask the user to paste private keys, client secrets, or tokens into ordinary chat. The form must distinguish public identifiers from secret values. Wait for user-provided configuration or explicit approval before proceeding.
6. **Implementation plan approval.** Present milestones, repository structure, risks, and test plan. Wait for approval if the Arena environment requires explicit approval.
7. **Implementation.** Build incrementally, run tests after each stage, and keep the app compiling.
8. **Release verification.** Deliver source, debug/release build instructions, CI results, test report, known limitations, and exact artifact paths.

If any required service is unavailable, do not fabricate a working integration. Build a clear adapter interface and mark it as pending credentials or provider access.

---

## B. Product identity

- Product name: **AETHER AI**
- Tagline: **Your Personal Autonomous AI Agent**
- Platform: Android first; Flutter/Dart.
- Core engine: Hermes Agent (NousResearch project).
- Requested execution environment: GitHub Actions, subject to verified feasibility and policy.
- Brand asset: `assets/AETHER_AI_App_Icon_1024.png`. Use it as the app icon direction. Create Android launcher icon assets/adaptive icon foreground and background from this artwork while respecting Android safe-zone/mask guidance. Do not replace the brand with a generic icon.
- Visual direction: clean ChatGPT-inspired simplicity, premium dark theme, deep navy/near-black surfaces, restrained violet/purple accent, soft cyan highlights, high legibility, generous spacing, rounded cards, subtle shadows. Minimal, not cluttered.
- **No bottom NavigationBar.** Use a top app bar with hamburger button opening a navigation drawer/sidebar. The drawer includes New Chat and searchable conversation history.
- Responsive Android UI, accessible touch targets, keyboard-safe layouts, RTL Arabic support and LTR English/French support.
- Default UI language can be selected at onboarding. Do not hardcode sample user names.

---

## C. Main product concept

AETHER AI is not merely a chat client. It is a mobile control plane for a personal Hermes Agent that can:
- chat with the user;
- plan and execute multi-step tasks;
- use Hermes tools and skills;
- browse/search the web where configured;
- run code and terminal tasks in an isolated workspace;
- work with user-approved files;
- connect to external services using explicit OAuth/API permissions;
- manage projects, memory, conversations, and skills;
- use multiple AI model providers and fallback routing;
- save state before a temporary compute session ends;
- restore the same user's agent on a new session.

Hermes is the agent runtime and source of agent capabilities. Do not reimplement Hermes features blindly. Research its current CLI, configuration, memory, skills, tools/toolsets, providers, MCP, security, session handling, and supported deployment model. Integrate through documented interfaces and stable APIs/CLI where possible. Pin tested Hermes versions/commits and provide an update strategy.

---

## D. User journey / onboarding

Implement these screens and states:

1. Splash / brand intro.
2. Welcome / Continue with GitHub.
3. GitHub authorization in the system browser or supported secure flow.
4. Show the authenticated GitHub account and requested permissions.
5. Repository workspace selection:
   - select an existing repository the user is authorized to use; or
   - create a new private repository for AETHER AI.
   - deleting a repository is a separate dangerous action requiring typed confirmation and explicit permission; never offer deletion as a casual onboarding step.
6. User profile:
   - preferred name Hermes should use;
   - preferred language;
   - timezone;
   - optional interests and working preferences;
   - optional profile context.
7. Agent persona:
   - agent display name;
   - avatar image upload or built-in avatar;
   - communication style (friendly, concise, formal, technical);
   - language;
   - optional custom system persona notes.
8. AI provider/model setup:
   - connect one or more providers;
   - add API keys securely;
   - choose default model and optional fallback;
   - test connection and show accurate status.
9. Permissions review:
   - list exactly what the agent may read/write/execute;
   - let user grant minimum necessary access;
   - explain dangerous permissions in plain language.
10. Setup summary and explicit **Install & Start Agent** action.
11. Installation progress:
   - prepare environment;
   - install/pin Hermes;
   - configure provider;
   - restore memory and skills;
   - validate health;
   - connect relay;
   - report Ready.

Allow the user to skip optional integrations and finish setup with one working model and chat first.

---

## E. GitHub integration and credentials

Research and compare:
- GitHub App (recommended candidate for repository-scoped, granular permissions, installation tokens, and organization/repository installation control).
- GitHub OAuth App (simpler user sign-in but may require broader classic scopes and has different authorization semantics).

Do not assume OAuth sign-in alone authorizes Actions workflow dispatch, repository creation, repository deletion, or access to private contents. Verify the exact API endpoints and permissions.

After the user chooses one, present a setup checklist with:
- application name;
- homepage URL;
- callback/redirect URL(s);
- setup URL if needed;
- webhook URL and webhook secret only if webhooks are used;
- Client ID / App ID (public identifiers);
- Client Secret (secret, if OAuth App);
- GitHub App private key PEM (secret, if GitHub App);
- App slug / installation ID (where relevant);
- requested account/repository installation scope;
- exact permissions and event subscriptions;
- local development callback and production callback;
- optional webhook secret and public endpoint;
- Actions workflow permissions and workflow_dispatch requirements.

Use placeholders and validation instructions. Do not invent IDs, URLs, secrets, or scopes. Do not expose secret values in logs or source control. Prefer GitHub App when it supports the complete required flow with least privilege. If GitHub App cannot meet a user-account action, explain whether user OAuth authorization is additionally required. Never create both apps unless the user approves the need.

### Credential UX
Create a credential setup wizard in the app/developer setup docs:
- show each required field, purpose, where to obtain it, whether it is public or secret, and validation method;
- secret inputs are masked;
- support local `.env`/secret manager or secure backend entry;
- never store secrets in Git, repository snapshots, chat history, analytics, crash reports, or plain SharedPreferences;
- allow connection test, revoke/disconnect, rotate secret, and least-privilege review.

---

## F. Repository-backed persistence

The user's preference is to keep persistent workspace data in their GitHub repository. Implement a careful versioned snapshot model, not a database-like commit for every token.

Suggested layout (adapt after research):
- `aether/agent/profile/` — non-secret persona/profile preferences;
- `aether/agent/config/` — non-secret, validated agent configuration;
- `aether/memory/` — curated memory and user-approved summaries;
- `aether/conversations/` — conversation metadata and compact snapshots;
- `aether/skills/` — custom skills and manifest metadata;
- `aether/projects/` — project metadata and checkpoints;
- `aether/sessions/` — session manifests, checkpoint IDs, timestamps, status;
- `aether/backups/` — encrypted compressed snapshots and manifests, subject to size limits.

Never store:
- API keys, OAuth tokens, GitHub App private key, session cookies, raw credentials;
- unencrypted sensitive personal files;
- arbitrary files without user approval.

Use a secret manager or protected runtime secrets for credentials. If the user insists that all data lives in GitHub, explain the distinction: versioned user data can be stored in a private repo, but secrets must be stored in a secure secret store, not committed to the repository. For sensitive data, encrypt client-side before upload, document key management, and do not commit encryption keys beside ciphertext.

Requirements:
- atomic checkpoint manifest;
- commit batching/debouncing;
- integrity hashes;
- schema versioning and migrations;
- rollback to previous checkpoint;
- conflict detection and safe merge;
- repository size monitoring;
- large-file strategy (Git LFS or external object storage only after cost/limits review);
- retention and user export/delete controls;
- verify successful remote save before stopping.

---

## G. Five-hour GitHub Actions session lifecycle

Requested product behavior:
- one session maximum of 5 hours;
- warn user before shutdown (configurable default 10 minutes);
- checkpoint state before shutdown;
- verify the checkpoint was pushed successfully;
- stop Hermes gracefully;
- end the job before the 5-hour application deadline;
- show Stopped status;
- Resume Agent launches a new session and restores last good checkpoint.

Important engineering constraints:
- GitHub-hosted runners are ephemeral and are not guaranteed inbound-reachable servers.
- Validate current maximum job duration and all relevant usage/policy constraints from official docs.
- Determine if a secure outbound relay can support interactive app chat without violating policy.
- Never rely on the runner's local disk after job termination.
- Do not use Actions artifacts/cache as the only permanent data store.
- Do not claim the agent is online unless a health check confirms it.
- Use concurrency groups/locks to prevent duplicate active sessions for one user/repository.
- Use heartbeats and stale-session cleanup.
- Implement graceful stop signal and shutdown handler.
- If the 5-hour interactive pattern is not technically or policy-compliantly supported by GitHub-hosted runners, stop and report it before coding the runtime. Present a user-approved compliant alternative (self-hosted runner or dedicated compute provider) while retaining GitHub for workflow orchestration and repository persistence.

Resume sequence:
1. app fetches latest session manifest;
2. validates user/repo access and checkpoint hash;
3. dispatches a new workflow;
4. runner checks out private repo;
5. restores pinned Hermes version and dependencies;
6. restores config, memory, skills, projects and conversations;
7. injects secrets securely;
8. runs health checks;
9. registers new session with relay;
10. app shows Running and reconnects to chat.

---

## H. AI Providers / API Key Manager

Build a dedicated **AI Providers** section. Support adapters only where official APIs and Hermes provider configuration allow them:
- OpenRouter;
- OpenAI API (ChatGPT subscription is not automatically API credit);
- Anthropic Claude API;
- Google Gemini API;
- DeepSeek API;
- Groq;
- Ollama (local/remote endpoint);
- Hugging Face Inference providers/endpoints;
- other OpenAI-compatible custom endpoints.

Features:
- add provider;
- enter API key securely;
- choose endpoint only when provider supports custom base URL;
- fetch available models from provider's official model catalog/API;
- test connection;
- select default model;
- select fallback model;
- show context window and capability metadata where available;
- show pricing/status only when live source provides it;
- label free models only when current official model metadata confirms free pricing;
- rate-limit and quota information where available;
- remove/rotate key;
- provider-specific setup instructions;
- never send an API key to a third party other than the chosen provider.

Do not hardcode a permanent “free models” list. Refresh it from provider catalogs. For OpenRouter, inspect its current model API and free-model catalog; free variants may be rate-limited and can change. Clearly distinguish $0 model pricing from account credit requirements, quotas, and availability.

---

## I. Skills Manager

Use Hermes' actual Skills system and documented Skills Hub/source support. Research the current skill format, skill discovery, install/uninstall/update, and security scanning.

Screens:
- Explore Skills / marketplace;
- categories (development, web research, documents, data, cloud/devops, automation, productivity);
- search/filter;
- skill detail (description, author/source, version, permissions, dependencies, last updated);
- install/uninstall/update;
- My Skills;
- create custom skill;
- upload ZIP or import from supported Git repository;
- validate skill manifest and SKILL.md;
- preview files and instructions;
- scan for suspicious instructions/scripts;
- ask permission before enabling dangerous tools;
- export/share skill.

Skills must persist between sessions in the private repository (after validating format and licensing) and be restored into Hermes' expected skills directory. Never silently install arbitrary code. A skill is not automatically safe because it is a Markdown file; inspect scripts, URLs, and instructions.

---

## J. Integrations Hub

Design an extensible integration framework with explicit per-service scopes:
- Google Drive: browse/search/read/upload/update only as authorized;
- Gmail: search/read/draft/send, with send confirmation by default;
- Google Calendar: read/create/update/delete events with explicit scopes;
- Google Sheets: read/write spreadsheets;
- GitHub: repositories, issues, pull requests, workflows and files according to granted permissions;
- Google Colab: support only documented, available integration methods; do not claim arbitrary notebook execution control if no supported API exists. Provide notebook export/import and Drive-backed workflow as a fallback;
- Telegram: bot messaging via official Bot API;
- custom MCP servers and API integrations where safe.

Each integration must show:
- Connect / Connected / Expired / Error;
- account identity;
- granted scopes;
- last successful sync;
- test connection;
- disconnect/revoke;
- scope review;
- action audit trail.

Use OAuth authorization-code flow with PKCE where supported. Verify redirect URI and scope rules from each provider's official docs. Ask confirmation for consequential actions such as sending emails, deleting files, publishing, or modifying calendars.

---

## K. App screens

Implement at minimum:
1. Splash / launch.
2. Welcome / GitHub sign-in.
3. OAuth callback/result and account identity.
4. GitHub permission review.
5. Select or create private repository.
6. User profile setup.
7. Agent persona/avatar setup.
8. AI model/provider setup.
9. API key add/edit/test.
10. Free model catalog.
11. Installation/setup progress.
12. Setup complete.
13. Welcome Back / Resume Agent.
14. Main AI Chat.
15. Sidebar/navigation drawer with New Chat and searchable full chat history.
16. Conversation search and chat details.
17. Skills Manager marketplace.
18. Skill detail/install/scan.
19. Create/upload custom skill.
20. Integrations Hub.
21. Integration permissions/details.
22. Session monitor and logs.
23. Memory & Data manager.
24. Projects workspace.
25. File manager.
26. Agent task execution timeline.
27. Settings, privacy and security.
28. Notifications/activity.
29. Error/recovery/connection screens.

The screen reference images are in `assets/ui_pages/`. Use them as visual direction, not as pixel-perfect or content-authoritative sources. Where a page has a specification-only placeholder, follow the detailed written spec.

---

## L. Main chat UX

ChatGPT-inspired clean interface:
- top bar with hamburger, agent avatar/name/status, optional session status, notifications;
- no bottom navigation bar;
- chat bubbles with readable typography;
- streaming responses;
- markdown, code highlighting, copy, retry, regenerate;
- file attachment and file picker;
- voice input only if implemented with correct permissions and provider support;
- task progress panel with steps/tools and cancel action;
- tool activity details and approval prompts;
- input composer fixed above keyboard;
- offline/reconnecting/error states;
- conversation history saved to the repository snapshot system;
- sidebar with New Chat, Search, pinned and recent chats, Skills, AI Providers, Integrations, Memory, Projects, Sessions, Settings.

Do not expose hidden chain-of-thought. Show concise task status, tool actions, progress, and results only.

---

## M. Android / Flutter engineering requirements

- Native Flutter widgets; do not build the app as a WebView.
- Follow current Flutter architecture guidance; use a feature-first modular structure and clear separation of presentation, domain/use cases, repositories, and services.
- Choose state management after a short documented evaluation (e.g., Riverpod or Bloc); do not mix patterns randomly.
- Use typed models, immutable state where practical, dependency injection, navigation guards, and centralized error handling.
- Use secure storage for secrets only if secrets must be stored on-device; prefer short-lived tokens and backend-held credentials.
- Use Android system browser/Custom Tabs for OAuth and Android Storage Access Framework / system photo picker for user-selected files.
- Support Android 8+ unless research recommends a different minimum; state the chosen minSdk and justify it.
- Support Arabic RTL, English and French localization.
- Avoid overflows on 360px-wide devices; support large font scaling and keyboard insets.
- Add light/dark only if requested; default is dark.
- Add accessibility semantics, contrast, scalable text, and minimum touch target.
- Use environment-specific config and no hardcoded secrets.
- Add unit, widget, integration, and API contract tests.
- CI: format, analyze, tests, build APK/AAB, and produce checksums.
- App must have a real launcher icon using the supplied AETHER asset.

---

## N. Deliverables

Before coding:
- research report;
- feasibility report;
- architecture diagram;
- GitHub App vs OAuth decision;
- setup credential form and instructions;
- implementation plan.

During/after coding:
- complete Flutter source project;
- GitHub Actions workflow(s);
- secure backend/relay only if proven necessary and approved;
- data schema and migration plan;
- setup documentation;
- tests and CI workflow;
- APK/AAB release artifact;
- changelog and SHA-256 checksum;
- known limitations and manual setup steps.

Do not say “complete” if a screen is only mocked, an integration has no real API, or the agent runtime is not connected. Label features accurately as Implemented, Partially implemented, Mocked, or Blocked.

### Definition of done
The app builds, tests pass, GitHub authorization works with real test credentials, private repo selection/creation works, one provider connects, Hermes runs in a verified supported environment, chat can exchange messages, memory/skills restore from a saved checkpoint, and the user can stop/resume a session without losing committed state. Any unverified GitHub-hosted runner limitation must be disclosed and approved before claiming success.
