# 05 — ARCHITECTURE AND WORKFLOWS
## Logical components
1. Flutter Android client: UI, onboarding, chat, approvals, provider setup and status.
2. Auth/control service (only if required by the verified architecture): handles GitHub OAuth/App exchange, short-lived token issuance, workflow dispatch and relay registration. It must not become an undocumented permanent agent host.
3. GitHub App/OAuth integration: repository authorization, selected repo access and workflow orchestration.
4. GitHub Actions runner: ephemeral worker, installs pinned Hermes and runs the agent only if verified technically and policy-compliantly.
5. Hermes Agent: core runtime, tools, memory, skills and model provider.
6. Secure relay/gateway: outbound authenticated channel between Flutter and worker if feasible; design reconnect, heartbeats, session identity and replay protection.
7. Private GitHub repository: versioned non-secret snapshots, project files, skill manifests and checkpoint manifests.
8. External provider APIs: model inference.
9. External integrations: Google and other OAuth/API services.

## Session state machine
Idle → Queued → Starting → Installing → Restoring → Running → Checkpointing → Stopping → Stopped.
Any failure transitions to Failed or RecoveryRequired. Only a successful health check sets Running. Only verified remote checkpoint sets Saved.

## Five-hour lifecycle
- Set the job timeout to a safe value consistent with current GitHub limits; target 5 hours for application-level runtime, not a 5-hour abrupt kill.
- Start an internal deadline timer at runtime startup.
- At T-10 minutes: notify app, stop accepting long tasks or ask the user to checkpoint.
- Save conversation delta, curated memory, skill manifest, project state and session metadata.
- Upload/commit snapshot atomically and verify commit/hash from GitHub.
- If save fails, retry with bounded backoff and keep the runtime alive only within the safe deadline; notify user. Never claim Saved without remote verification.
- Gracefully stop Hermes and close relay.
- End workflow before the hard timeout.
- On next Resume, dispatch new run, restore snapshot and health-check.

## Critical feasibility caveat
GitHub-hosted Actions runners are ephemeral CI workers, not general-purpose interactive servers. A job may not accept inbound network connections; a long-running agent connected through an outbound relay must be validated. Confirm GitHub's current policy and product limits. If this model is not approved or reliable, stop and offer a self-hosted runner or dedicated compute provider with GitHub Actions used for orchestration. User approval is mandatory before changing hosting.

## Persistence protocol
- Store versioned snapshot metadata.
- Use atomic commit or manifest-last strategy.
- Hash every snapshot file.
- Keep last known-good checkpoint and previous versions.
- Avoid one commit per chat token; batch writes.
- Store binary large files separately or use approved storage after evaluating limits.
- Store only encrypted user-approved data.
- Keep all secrets out of Git.
- Support conflict detection and rollback.

## Relay security
- TLS only.
- Per-session short-lived credential.
- Bind session ID, user ID and repository identity.
- Heartbeat and expiry.
- Replay protection / nonce.
- Rate limits and message size limits.
- No arbitrary unauthenticated port.
- Tool permissions enforced server-side, not just hidden in UI.
- Audit consequential actions.
