# 07 — UI DESIGN REFERENCE
## Brand
- Name: AETHER AI.
- Tagline: Your Personal Autonomous AI Agent.
- Icon: `assets/AETHER_AI_App_Icon_1024.png`.
- Look: ChatGPT-inspired simplicity with premium dark navy, subtle violet accent and occasional cyan highlights.
- Do not use a crowded cyberpunk dashboard as the primary app UI. Concept boards are mood references; real screens must be cleaner and more usable.

## Global rules
- No bottom navigation bar.
- Top app bar with hamburger, title/agent status, avatar and optional notifications.
- Hamburger opens a drawer with New Chat, searchable recent chats and app sections.
- Main chat composer remains keyboard-safe.
- Cards should be restrained; use clear typography and whitespace.
- Arabic supports RTL; icons and navigation direction should adapt appropriately.
- Provide loading, empty, offline, error, permission-denied and success states.

## Page-by-page reference
The `assets/ui_pages/` directory contains separate image files. Use each as a visual hint. Do not copy unreadable generated text or sample identities.

1. Splash — brand logo, concise tagline, short transition.
2. GitHub Login — one primary Continue with GitHub action.
3. GitHub Permissions — plain-language scope list and approve/cancel.
4. Repository Setup — existing repo picker or create private repo.
5. User Profile — preferred name, language, timezone, optional notes.
6. Agent Persona — agent name, avatar, style and personality.
7. AI Model Selection — provider and model selector.
8. Welcome Back & Resume — last session status, last checkpoint, Resume Agent and Start New Session.
9. AI Chat — clean ChatGPT-like conversation, streaming, tools, attachments, composer.
10. Sidebar — New Chat, search, recent/pinned chats and destinations.
11. Skills Manager — Explore/My Skills/Create Skill, search and categories.
12. Integrations Hub — service cards, connection state, scopes and disconnect.
13. AI Providers — provider list, model status and default/fallback.
14. Add API Key — provider selection, masked key field, endpoint/model, test and save.
15. Free Models Catalog — live results, current availability, rate limit and source.
16. Session Monitor — state, elapsed/remaining time, heartbeat, logs and stop/save controls.
17. Memory & Data — memory summary, conversations, projects, backups, export/delete.
18. Projects — project cards, recent activity, files and checkpoints.
19. Settings & Security — profile, privacy, app language, secret rotation and audit.
20. Skill Detail/Create — description, source, version, permissions, file preview and security scan.
21. Task Execution — step timeline, tool status, approval requests, cancel.
22. File Manager — user-selected files and project assets.
23. Voice/Notifications — only if implemented and permission granted.

## Image references
- Full boards: `assets/UI_Concept_Full_Showcase.png`, `assets/UI_Concept_Chat_Providers.png`, `assets/UI_Concept_Original_Home.png`.
- Separate page images: `assets/ui_pages/`.
- Some files named 16–23 are specification-only placeholder cards because the concept boards did not contain dedicated screen mockups. Build them from this document and create real screen mockups during design.
