# 03 — REQUIRED RESEARCH PLAN AND OFFICIAL SOURCES
## Research rule
Arena must browse current primary documentation and inspect current source code before implementation. Record access date, versions, relevant API endpoints, permissions, deprecations and unresolved questions. Do not rely on old tutorials or third-party summaries where official documentation exists.

## Flutter and Dart
- Flutter documentation: https://docs.flutter.dev/
- Flutter architecture guide: https://docs.flutter.dev/app-architecture/guide
- Flutter architecture overview: https://docs.flutter.dev/app-architecture
- Flutter navigation: https://docs.flutter.dev/ui/navigation
- Flutter testing: https://docs.flutter.dev/testing/overview
- Flutter internationalization: https://docs.flutter.dev/ui/accessibility-and-internationalization/internationalization
- Flutter Android deployment: https://docs.flutter.dev/deployment/android
Research: supported stable version, Dart version, project architecture, state management, routing, secure storage, deep links, app lifecycle, Android permissions, RTL, testing and release signing.

## Hermes Agent
- Official repository: https://github.com/NousResearch/hermes-agent
- Official documentation: https://hermes-agent.nousresearch.com/docs/
- Quickstart: https://hermes-agent.nousresearch.com/docs/getting-started/quickstart/
- Skills: https://hermes-agent.nousresearch.com/docs/user-guide/features/skills/
Research current install process, supported platforms, Python/runtime requirements, CLI commands, providers, config files, memory layout, sessions, skills, toolsets, MCP, browser/web search, security/approvals, terminal backends, persistence, and version pinning. Confirm whether Hermes is suitable for a headless ephemeral Linux worker and how to expose a secure chat interface. Do not invent an API; use a supported CLI, gateway, ACP or documented interface.

## GitHub App / OAuth / Actions
- GitHub Apps: https://docs.github.com/en/apps
- GitHub App authentication: https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app
- User authorization for GitHub Apps: https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/authorizing-oauth-apps
- OAuth Apps: https://docs.github.com/en/apps/oauth-apps
- OAuth authorization: https://docs.github.com/en/apps/oauth-apps/building-oauth-apps/authorizing-oauth-apps
- Device flow: https://docs.github.com/en/apps/oauth-apps/building-oauth-apps/authorizing-oauth-apps/authorizing-oauth-apps
- Actions workflow syntax: https://docs.github.com/en/actions/writing-workflows/workflow-syntax-for-github-actions
- Workflow dispatch API: https://docs.github.com/en/rest/actions/workflows
- Runner limits: https://docs.github.com/en/actions/reference/limits
- Secure use reference: https://docs.github.com/en/actions/security-for-github-actions/security-guides/security-hardening-for-github-actions
Research exact current maximum job duration, hosted runner availability, billing and usage policies, public/private repository limits, network model, inbound access, workflow_dispatch permissions, GitHub App permissions, repo create/delete endpoints, installation tokens, token expiry, concurrency, artifacts, cache, storage, webhooks and acceptable use. Explicitly assess whether using a hosted Actions runner as an interactive agent host is allowed and reliable.

## AI provider APIs
- OpenRouter API: https://openrouter.ai/docs/api-reference/overview
- OpenRouter models: https://openrouter.ai/models
- OpenRouter free models: https://openrouter.ai/collections/free-models
- OpenAI API: https://platform.openai.com/docs/
- Anthropic API: https://docs.anthropic.com/
- Gemini API: https://ai.google.dev/gemini-api/docs
- DeepSeek API: https://api-docs.deepseek.com/
- Groq API: https://console.groq.com/docs
- Ollama API: https://github.com/ollama/ollama/blob/main/docs/api.md
- Hugging Face Inference: https://huggingface.co/docs/inference-providers/index
Research model discovery, authentication, chat/tool calling, streaming, quotas, free tiers, rate limits, base URLs, usage metadata, provider terms and Hermes compatibility. Do not equate ChatGPT/Claude consumer subscriptions with API credits.

## Google and external integrations
- Google OAuth: https://developers.google.com/identity/protocols/oauth2
- Drive API: https://developers.google.com/workspace/drive/api/guides/about-sdk
- Gmail API: https://developers.google.com/workspace/gmail/api/guides
- Calendar API: https://developers.google.com/workspace/calendar/api/guides/overview
- Sheets API: https://developers.google.com/workspace/sheets/api/guides/concepts
- Colab FAQ: https://research.google.com/colaboratory/faq.html
- Telegram Bot API: https://core.telegram.org/bots/api
Research OAuth scopes, verification/testing requirements, quotas, supported actions, refresh token handling, PKCE, and limits. Treat Colab as a separate product: only implement operations supported by its documented interfaces; do not claim arbitrary remote runtime control.

## Android security and storage
- Android app links/deep links: https://developer.android.com/training/app-links
- Android photo picker: https://developer.android.com/training/data-storage/shared/photopicker
- Android secure storage/Keystore: https://developer.android.com/privacy-and-security/keystore
Research file picker/Storage Access Framework, biometric protection if useful, deep-link callback validation, secure token storage, notification permission and Android lifecycle.

## Deliverable from research
Produce a table: Topic | Current finding | Official source | Implementation impact | Risk | Decision. Then write a feasibility verdict and stop for user approval if the GitHub Actions interactive-hosting model is not viable or not policy-compliant.
